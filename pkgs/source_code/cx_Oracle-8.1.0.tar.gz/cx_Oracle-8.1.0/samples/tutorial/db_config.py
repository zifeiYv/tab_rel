user = "pythonhol"
pw = "welcome"
dsn = "localhost/orclpdb1"
