enum Lang {
    CPP = 0,
    Python,
    Ruby = 2,
}

const Lang my_lang = 3
