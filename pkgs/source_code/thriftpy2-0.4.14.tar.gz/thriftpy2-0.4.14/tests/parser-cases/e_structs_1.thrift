struct User {
    1: string name,
    2: i32 age,
    3: string email
}

const User user = {'avatar': '/avatar.jpg'}
