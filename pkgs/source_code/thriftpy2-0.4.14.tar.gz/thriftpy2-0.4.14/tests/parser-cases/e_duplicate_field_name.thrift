struct Foo {
1: required i32 abc
2: required i32 abc
}
