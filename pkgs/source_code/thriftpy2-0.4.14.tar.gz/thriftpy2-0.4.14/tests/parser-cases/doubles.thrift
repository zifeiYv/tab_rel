struct Book {
    1: string name,
    2: double price = 1,
}

const double value1 = 3;
const double value2 = 3.1;
const double value3 = 1e5;
const double value4 = -1.5e-5
const double value5 = +1.5E+5
const double value6 = .13;
