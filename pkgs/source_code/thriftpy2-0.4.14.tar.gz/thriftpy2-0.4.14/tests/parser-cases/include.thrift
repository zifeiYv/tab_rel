include "included.thrift"

const included.Timestamp datetime = 1422009523
