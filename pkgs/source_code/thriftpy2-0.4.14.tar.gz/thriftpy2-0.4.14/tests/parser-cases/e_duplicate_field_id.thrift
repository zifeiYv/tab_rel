struct Foo {
1: required i32 abc
1: required i32 efg
}
