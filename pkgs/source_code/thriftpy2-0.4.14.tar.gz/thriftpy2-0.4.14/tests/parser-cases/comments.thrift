/*
 * C/CPP like comments
 */

/** 
 * Silly comments
 */

# Python like comments
