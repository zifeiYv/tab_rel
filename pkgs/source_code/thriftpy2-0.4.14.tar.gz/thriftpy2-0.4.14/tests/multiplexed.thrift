service ThingOneService {
    bool doThingOne();
}

service ThingTwoService {
    bool doThingTwo();
}
