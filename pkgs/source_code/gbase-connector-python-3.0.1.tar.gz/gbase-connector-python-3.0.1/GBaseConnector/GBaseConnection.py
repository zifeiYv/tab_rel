import time
from . import GBaseLogger
global GBASELOGGER

from GBaseConnector.GBaseCursor import GBaseCursor
from GBaseConnector.GBaseSocket import GBaseSocket
from GBaseConnector.GBaseProtocol import GBaseProtocol
from GBaseConnector.GBaseConstants import (ClientFlag, ServerCmd, flag_is_set,
                                           ServerFlag, CharacterSet)
from GBaseConnector import GBaseError

class GBaseConnection(object):
    '''
    ************************************************************
        Module      : GBaseConnection
        Function    : Create connection to GBase server
        Corporation : General Data Technology CO,. Ltd.
        Team        : DMD, Interface Team
        Author      : wq
        Date        : 2013-7
        Version     : v1.0
        Description : Create connection to GBase server. And execute 
                      SQL and fetch rows.
    ************************************************************
    '''
    def __init__(self, **kwargs):
        '''
        ************************************************************
            Function    : __init__
            Arguments   : 1) **kwargs (dict) : connection arguments
                                                { 'user': gbase,
                                                  'port': 5258  }
            Return      : 
            Description : GBaseConnection construct function
        ************************************************************
        '''
        self._host = '127.0.0.1'
        self._user = ''
        self._password = ''
        self._database = ''
        self._port = 5258
        self.charset = None
        self._use_unicode = True
        self._collation = None
        self._connection_timeout = 30
        self._autocommit = True
        self._time_zone = None
        self._sql_mode = None
        self._get_warnings = False
        self._raise_on_warnings = False
        
        self._client_flags = ClientFlag.get_default()
        self._charset_id = 33  # utf8
        
        self._socket = None
        self._protocol = None
        self._hello_res = None
        self._server_version = None
        self._have_next_result = False 
        self._unread_result = False
        
        # Initial log system
        GBaseLogger.InitLog(**kwargs)
        
        if len(kwargs) > 0:            
            self.connect(**kwargs)
        
    def parsecfg(self, **kwargs):
        '''
        ************************************************************
            Function    : parsecfg
            Arguments   : 1) **kwargs (dict) : connection arguments
                                                { 'user': gbase,
                                                  'port': 5258  }
            Return      : 
            Description : Parse config arguments and get values.
        ************************************************************
        '''
        GBASELOGGER.debug('Enter: parsecfg')
        config = kwargs.copy()
        # dsn
        if 'dsn' in config:
            GBASELOGGER.error('Not support dsn key word.')
            raise GBaseError.NotSupportedError('Not support dsn key word.')
        
        # host
        if 'host' in config:
            if config['host'] != None and len(config['host']) > 0:  # Bug #2857
                self._host = config['host']
            del config['host']
            
        # user
        if 'user' in config:
            self._user = config['user']
            del config['user']

        # Compatible other key
        compatible_keys = [
            ('db', 'database'),
            ('passwd', 'password'),
            ('connect_timeout', 'connection_timeout'),
        ]
        
        for comp_key, full_key in compatible_keys:
            try:
                if full_key not in config:
                    config[full_key] = config[comp_key]
                del config[comp_key]
            except KeyError:
                pass  # Missing compat argument is OK

        # password
        if 'password' in config:
            self._password = config['password']
            del config['password']
            
        # port
        if 'port' in config: 
            try:
                self._port = int(config['port'])
                del config['port']
            except KeyError:
                pass # Missing port argument is OK
            except ValueError:
                raise ValueError(
                    "TCP/IP port number should be an integer")
            
        if 'connection_timeout' in config:
            self.connection_timeout = config['connection_timeout']
            del config['connection_timeout']
        
        if 'autocommit' in config:
            self._autocommit = config['autocommit']
            del config['autocommit']
            
        if 'sql_mode' in config:
            self.sql_mode = config['sql_mode']
            del config['sql_mode']
            
        if 'get_warnings' in config:
            self.get_warnings = config['get_warnings']
            del config['get_warnings']
        
        # Configure client flags
        try:
            default = ClientFlag.get_default()
            self.set_client_flags(config['client_flags'] or default)
            del config['client_flags']
        except KeyError:
            pass  # Missing client_flags-argument is OK
        
        # Configure character set and collation
        if ('charset' in config or 'collation' in config):
            try:
                self.charset = config['charset']
                del config['charset']
            except KeyError:
                self.charset = None
            try:
                collation = config['collation']
                del config['collation']
            except KeyError:
                collation = None
            self._charset_id = CharacterSet.get_charset_info(self.charset, collation)[0]
        
        if 'raise_on_warnings' in config:
            self.raise_on_warnings = config['raise_on_warnings']
            del config['raise_on_warnings']
        
        if 'use_unicode' in config:
            self.use_unicode = config["use_unicode"]
            del config['use_unicode']
            
        # Other configuration
        for k, v in list(config.items()):
            # TRACE Configuration
            if k.startswith('trace'):
                continue
            
            try:
                self.DEFAULT_CONFIG[k]
            except KeyError:
                raise AttributeError("The argument is not support. '%s'" % k)
            
            attribute = '_' + k
            try:
                setattr(self, attribute, v.strip())
            except AttributeError:
                setattr(self, attribute, v)
        GBASELOGGER.debug('Exit: parsecfg')
    
    @property
    def port(self):
        '''
        ************************************************************
            Function    : port
            Arguments   : 
            Return      : int 
            Description : Return current port.
        ************************************************************
        '''
        return self._port
    
    @property
    def user(self):
        '''
        ************************************************************
            Function    : user
            Arguments   : 
            Return      : string 
            Description : Return current user.
        ************************************************************
        '''
        return self._user
    
    @property
    def host(self):
        '''
        ************************************************************
            Function    : host
            Arguments   : 
            Return      : string 
            Description : Return current host.
        ************************************************************
        '''
        return self._host
    
    def _get_use_unicode(self):
        '''
        ************************************************************
            Function    : _get_use_unicode
            Arguments   :
            Return      : bool
            Description : Get self._use_unicode property value
        ************************************************************
        '''
        return self._use_unicode
    def _set_use_unicode(self, value):
        '''
        ************************************************************
            Function    : _set_use_unicode
            Arguments   : 1) value (bool): property value
            Return      : 
            Description : Set self._use_unicode property value and check its
                          valid.
        ************************************************************
        '''
        if not isinstance(value, bool):
            GBASELOGGER.error("use_unicode '%s' is not valid." % value)
            raise ValueError("use_unicode '%s' is not valid." % value)
        self._use_unicode = value
    use_unicode = property(_get_use_unicode, _set_use_unicode) 
    
    def _get_connection_timeout(self):
        '''
        ************************************************************
            Function    : _get_connection_timeout
            Arguments   : 
            Return      : int
            Description : Get self._connection_timeout property value.
        ************************************************************
        '''
        return self._connection_timeout
    def _set_connection_timeout(self, value):
        '''
        ************************************************************
            Function    : _set_connection_timeout
            Arguments   : 1) value (int): property value
            Return      : 
            Description : Set self._connection_timeout property value and check its
                          valid.
        ************************************************************
        '''
        if not isinstance(value, int):
            GBASELOGGER.error("connection_timeout '%s' is not valid." % value)
            raise ValueError("connection_timeout '%s' is not valid." % value)
        if value <= 0: 
            value = self._connection_timeout
        self._connection_timeout = value
    connection_timeout = property(_get_connection_timeout, _set_connection_timeout)
    
    def _get_autocommit(self):
        '''
        ************************************************************
            Function    : _get_autocommit
            Arguments   : 
            Return      : bool
            Description : Get self._autocommit property value.
        ************************************************************
        '''
        return self._autocommit
    def _set_autocommit(self, value):
        '''
        ************************************************************
            Function    : _set_autocommit
            Arguments   : 1) value (bool): property value
            Return      : 
            Description : Get self._autocommit property value and check its
                          valid.
        ************************************************************
        '''
        if not isinstance(value, bool):
            GBASELOGGER.error("autocommit '%s' is not valid." % value)
            raise ValueError("autocommit '%s' is not valid." % value)
        if value:
            self.query("set autocommit = 1")
        else:
            self.query("set autocommit = 0")
        self._autocommit = value
    autocommit = property(_get_autocommit, _set_autocommit)
    
    def _get_sql_mode(self):
        '''
        ************************************************************
            Function    : _get_sql_mode
            Arguments   : 
            Return      : dict
            Description : Get self._sql_mode property value.
        ************************************************************
        '''
        return self._query_info("SELECT @@session.sql_mode")[0]
    
    def _set_sql_mode(self, value):
        '''
        ************************************************************
            Function    : _set_sql_mode
            Arguments   : 1) value (bool): property value
            Return      : 
            Description : Get self._sql_mode property value and check its
                          valid.
        ************************************************************
        '''
        if isinstance(value, (list, tuple)):
            value = ','.join(value)
        self.query("SET @@session.sql_mode = '%s'" % value)
        self._sql_mode = value
        
    sql_mode = property(_get_sql_mode, _set_sql_mode)
    
    def _get_get_warnings(self):
        '''
        ************************************************************
            Function    : _get_get_warnings
            Arguments   : 
            Return      : bool
            Description : Get self._get_warnings property value.
        ************************************************************
        '''
        return self._get_warnings
    def _set_get_warnings(self, value):
        '''
        ************************************************************
            Function    : _set_get_warnings
            Arguments   : 1) value (bool): property value
            Return      : 
            Description : Get self._get_warnings property value and check its
                          valid.
        ************************************************************
        '''
        if not isinstance(value, bool):
            GBASELOGGER.error("get_warnings '%s' is not valid." % value)
            raise ValueError("get_warnings '%s' is not valid." % value)
        self._get_warnings = value
    get_warnings = property(_get_get_warnings, _set_get_warnings)
    
    def _get_raise_on_warnings(self):
        '''
        ************************************************************
            Function    : _get_raise_on_warnings
            Arguments   : 
            Return      : bool
            Description : Get self._raise_on_warnings property value.
        ************************************************************
        '''
        return self._raise_on_warnings
    def _set_raise_on_warnings(self, value):
        '''
        ************************************************************
            Function    : _set_raise_on_warnings
            Arguments   : 1) value (bool): property value
            Return      : 
            Description : Get self._raise_on_warnings property value and check its
                          valid.
        ************************************************************
        '''
        if not isinstance(value, bool):
            GBASELOGGER.error("raise_on_warnings '%s' is not valid." % value)
            raise ValueError("raise_on_warnings '%s' is not valid." % value)
        self._raise_on_warnings = value
    raise_on_warnings = property(_get_raise_on_warnings, _set_raise_on_warnings)
    
    def _get_unread_result(self):
        '''
        ************************************************************
            Function    : _get_unread_result
            Arguments   : 
            Return      : bool
            Description : Get self._unread_result property value.
        ************************************************************
        '''
        return self._unread_result
    def _set_unread_result(self, value):
        '''
        ************************************************************
            Function    : _set_raise_on_warnings
            Arguments   : 1) value (bool): property value
            Return      : 
            Description : Get self._unread_result property value and check its
                          valid.
        ************************************************************
        '''
        if not isinstance(value, bool):
            raise ValueError("unread_result '%s' is not valid." % value)
        self._unread_result = value
    unread_result = property(_get_unread_result, _set_unread_result)
    
    def set_time_zone(self, value):
        '''
        ************************************************************
            Function    : set_time_zone
            Arguments   : 1) value (string): time_zone value
            Return      : 
            Description : Set the time zone.
        ************************************************************
        '''
        self.query("SET @@session.time_zone = '%s'" % value)
        self._time_zone = value
    def get_time_zone(self):
        '''
        ************************************************************
            Function    : get_time_zone
            Arguments   : 
            Return      : dict
            Description : Get the current time zone
        ************************************************************
        '''
        return self._query_info("SELECT @@session.time_zone")[0]
    time_zone = property(get_time_zone, set_time_zone)
    
    def set_database(self, value):
        '''
        ************************************************************
            Function    : set_database
            Arguments   : 
            Return      : 
            Description : Set the current database
        ************************************************************
        '''
        self.query("USE %s" % value)
    def get_database(self):
        '''
        ************************************************************
            Function    : get_database
            Arguments   : 
            Return      : dict
            Description : Get the current database
        ************************************************************
        '''
        return self._query_info("SELECT DATABASE()")[0]
    database = property(get_database, set_database)
    
    def set_client_flags(self, flags):
        '''
        ************************************************************
            Function    : set_client_flags
            Arguments   : 1) flags (int): client flags value
            Return      : int
            Description : Set the client flags
                          set_client_flags([ClientFlag.FOUND_ROWS,-ClientFlag.LONG_FLAG])
        ************************************************************
        '''
        if isinstance(flags, int) and flags > 0:
            self._client_flags = flags
        elif isinstance(flags, (tuple, list)):
            for flag in flags:
                if flag < 0:
                    self._client_flags &= ~abs(flag)
                else:
                    self._client_flags |= flag
        else:
            GBASELOGGER.error("set_client_flags expect int (>0) or set")
            raise GBaseError.ProgrammingError("set_client_flags expect int (>0) or set")

        return self._client_flags
    
    def connect(self, **kwargs):
        '''
        ************************************************************
            Function    : connect
            Arguments   : 1) **kwargs (dict) : connection arguments
                                                { 'user': gbase,
                                                  'port': 5258  }
            Return      : 
            Description : connect to GBase server
        ************************************************************
        '''
        GBASELOGGER.debug("Enter: connect.")
        
        if len(kwargs) > 0:            
            self.parsecfg(**kwargs)
                
        self._protocol = self._get_protocol()        
        self.disconnect()        
        self._open_connection()
        
        GBASELOGGER.debug("Exit: connect.")
        
    def _get_protocol(self):
        '''
        ************************************************************
            Function    : _get_protocol
            Arguments   : 
            Return      : instance of GBaseProtocol class
            Description : Create protocal object
        ************************************************************
        '''
        GBASELOGGER.debug('Enter: _get_protocol')
        protocol = self._protocol
        if protocol is None:
            protocol = GBaseProtocol()
        
        GBASELOGGER.debug('Exit: _get_protocol')
        return protocol
    
    def _get_connection(self):
        '''
        ************************************************************
            Function    : _get_connection
            Arguments   : 
            Return      : 
            Description : Only support TCP socket
        ************************************************************
        '''
        GBASELOGGER.debug('Enter: _get_connection')
        socket = None
        hosts = self._host
        errmsg = ''
        errno = 0
        if isinstance(self._host, str):
            hosts = [self._host]
        for host in hosts:
            try:
                socket = GBaseSocket(host=host, port=self._port,
                                     timeout=self.connection_timeout)
            except GBaseError.InterfaceError as err:
                errmsg = str(err)
                errno = err.errno
                GBASELOGGER.error(str(err))
        if socket is None:
            raise GBaseError.InterfaceError(errmsg, errno)
        GBASELOGGER.debug('Exit: _get_connection')
        return socket
    
    def _open_connection(self):
        '''
        ************************************************************
            Function    : _open_connection
            Arguments   : 
            Return      : 
            Description : Use socket object open connection and make auth check
                          1) receive hello packet (shake hands)
                          2) auth check (user, pass)
                          3) set character
                          4) set auto commit
        ************************************************************
        '''
        GBASELOGGER.debug('Enter: _open_connection')
        # open socket        
        self._socket = self._get_connection()

        # hand shake        
        self._do_hello()
        
        # auth check        
        if self._do_authcheck():
            #set charset
            self.set_charset_collation(charset=self._charset_id)
            self._do_setotherinfo()
            pass
        
        GBASELOGGER.debug('Exit: _open_connection')
    
    def _do_setotherinfo(self):
        '''
        ************************************************************
            Function    : _do_setotherinfo
            Arguments   : 
            Return      : 
            Description : Set other initial info. Include autocommit, 
                          time_zone, sql_mode, etc.
        ************************************************************
        '''
        GBASELOGGER.debug("Enter: _do_setotherinfo")
        # set auto commit
        autocommit_sql = 'SET AUTOCOMMIT=%s' % self.autocommit
        self._exec_query(autocommit_sql)
        
        # set time_zone and sql_mode
        if self._time_zone:
            GBASELOGGER.debug('Set _time_zone.')
            self.time_zone = self._time_zone
        if self._sql_mode:
            GBASELOGGER.debug('Set _sql_mode.')
            self.sql_mode = self._sql_mode

        GBASELOGGER.debug("Exit: _do_setotherinfo")

    def _do_hello(self):
        '''
        ************************************************************
            Function    : _do_hello
            Arguments   : 
            Return      : 
            Description : Receive hello packet (shake hands).
                          Will receive to hello packet when first 
                          connect to GBase server
        ************************************************************
        '''
        GBASELOGGER.debug('Enter: _do_hello')                    
        packet = self._socket.receive_packet()                
        if self._protocol.is_error(packet):
            res = self._protocol.parse_error_res(packet)
            GBASELOGGER.error("Packet is error. Errno=%s ErrMsg=%s SqlState=%s" % 
                              (res['errno'], res['errmsg'], res['sqlstate']))
            GBASELOGGER.debug('Exit: _do_hello')            
            raise GBaseError.get_gbase_exception(res)

        hello_res = self._protocol.parse_hello_res(packet)        
        
        try:
            # get server version from package
            server_version = hello_res['server_version_original']
        except:
            GBASELOGGER.error('cannot get server_version.')
            GBASELOGGER.debug('Exit: _do_hello')
            raise GBaseError.InterfaceError('cannot get server_version.')      
        
        self._hello_res = hello_res
        self._server_version = server_version
        GBASELOGGER.debug('Exit: _do_hello')
        
    def _do_authcheck(self):
        '''
        ************************************************************
            Function    : _do_authcheck
            Arguments   : 
            Return      : bool
            Description : Send authorize check packet (user, pass)
        ************************************************************
        '''
        try:
            GBASELOGGER.debug('Enter: _do_authcheck.')
            packet = self._protocol.make_auth(self._user,
                                              self._password,
                                              self._hello_res['scramble'],
                                              self._database,
                                              self._charset_id,
                                              self._client_flags)
            
            self._socket.send_data(packet)
        
            # receive server packet            
            packet = self._socket.receive_packet()        

            if self._protocol.is_eof(packet):
                GBASELOGGER.error("Old passwords mode is not supported.")
                GBASELOGGER.debug('Exit: _do_authcheck.')
                raise GBaseError.NotSupportedError("Old passwords mode is not supported.")
                
            if self._protocol.is_error(packet):
                res = self._protocol.parse_error_res(packet)
                GBASELOGGER.error("Received error packet. Errno=%s ErrMsg=%s SqlState=%s" % 
                                  (res['errno'], res['errmsg'], res['sqlstate']))
                GBASELOGGER.debug('Exit: _do_authcheck.')
                raise GBaseError.get_gbase_exception(res)

            if (not (self._client_flags & ClientFlag.CONNECT_WITH_DB)
                and self._database):                
                self.initdb(self._database)
        except GBaseError.DatabaseError as err: # Bug #2889
            GBASELOGGER.debug('Exit: _do_authcheck.')
            raise
        except:
            GBASELOGGER.error("do authcheck error");
            GBASELOGGER.debug('Exit: _do_authcheck.')
            raise GBaseError.InterfaceError('do authcheck error')
        GBASELOGGER.debug('Exit: _do_authcheck.')
        return True
    
    def initdb(self, db):
        '''
        ************************************************************
            Function    : initdb
            Arguments   : db(string) : database name
            Return      : dict
            Description : Send initial database packet
        ************************************************************
        '''
        GBASELOGGER.debug('Enter: initdb.')
        packet = self._send(ServerCmd.INIT_DB, db)
        
        if self._protocol.is_error(packet):
            res = self._protocol.parse_error_res(packet)
            GBASELOGGER.error("Packet is error. Errno=%s ErrMsg=%s SqlState=%s" % 
                              (res['errno'], res['errmsg'], res['sqlstate']))
            GBASELOGGER.debug('Exit: initdb.')            
            raise GBaseError.get_gbase_exception(res)
        GBASELOGGER.debug('Exit: initdb.')
        return self._handle_ok(packet)
    
    def _handle_ok(self, packet):
        '''
        ************************************************************
            Function    : _handle_ok
            Arguments   : packet (string) : need handle packet
            Return      : dict
            Description : Handle ok packet.
        ************************************************************
        '''
        GBASELOGGER.debug('Enter: _handle_ok.')
        if self._protocol.is_ok(packet):            
            ok_packet = self._protocol.parse_ok_res(packet)            
            flag = ok_packet['server_status']            
            self._trigger_next_result(flag)
            
            GBASELOGGER.debug('Exit: _handle_ok.')
            return ok_packet
        elif self._protocol.is_error(packet):
            GBASELOGGER.error("No receive ok packet or package is error.")
            GBASELOGGER.debug('Exit: _handle_ok.')
            raise GBaseError.InterfaceError("No receive ok packet or package is error.")
        GBASELOGGER.debug('Exit: _handle_ok.')
        raise GBaseError.InterfaceError('Packet is not OK packet')
    
    def _handle_eof(self, packet):
        '''
        ************************************************************
            Function    : _handle_eof
            Arguments   : packet (string) : need handle packet
            Return      : list
            Description : Handle a GBase EOF packet
        ************************************************************
        '''
        GBASELOGGER.debug('Enter: _handle_eof.')
        
        if self._protocol.is_eof(packet):            
            eof_packet = self._protocol.parse_eof(packet)            
            server_flag = eof_packet['server_flag']            
            self._trigger_next_result(server_flag)
            
            GBASELOGGER.debug('Exit: _handle_eof.')
            return eof_packet
        elif self._protocol.is_error(packet):
            res = self._protocol.parse_error_res(packet)
            GBASELOGGER.error("Packet is error. Errno=%s ErrMsg=%s SqlState=%s" % 
                              (res['errno'], res['errmsg'], res['sqlstate']))
            
            GBASELOGGER.debug('Exit: _handle_eof.')            
            raise GBaseError.get_gbase_exception(res)

        GBASELOGGER.debug('Exit: _handle_eof.')
        raise GBaseError.InterfaceError('Expected EOF packet')
        
    def _handle_result(self, packet):
        '''
        ************************************************************
            Function    : _handle_result
            Arguments   : packet (string) : need handle packet
            Return      : dict
            Description : Get a GBase Result
        ************************************************************
        '''
        GBASELOGGER.debug("Enter: _handle_result.")
        if not packet or len(packet) < 4:
            GBASELOGGER.error('GBase Server can not response')
            GBASELOGGER.debug("Exit: _handle_result.")
            raise GBaseError.InterfaceError('GBase Server can not response')
        elif self._protocol.is_ok(packet):
            GBASELOGGER.debug("Exit: _handle_result.")
            return self._handle_ok(packet)
        elif self._protocol.is_eof(packet):
            GBASELOGGER.debug("Exit: _handle_result.")
            return self._handle_eof(packet)
        elif self._protocol.is_error(packet):
            res = self._protocol.parse_error_res(packet)
            GBASELOGGER.error("Packet is error. Errno=%s ErrMsg=%s SqlState=%s" % 
                              (res['errno'], res['errmsg'], res['sqlstate']))
            GBASELOGGER.debug("Exit: _handle_result.")            
            raise GBaseError.get_gbase_exception(res)

        # We have a text result set        
        column_count = self._protocol.parse_column_count(packet)
        if not column_count or not isinstance(column_count, int):
            GBASELOGGER.error('Result set is not valid.')
            GBASELOGGER.debug("Exit: _handle_result.")
            raise GBaseError.InterfaceError('Result set is not valid.')

        GBASELOGGER.debug("Loop receive column. count:'%s'" % column_count)
        columns = [None, ] * column_count
        for i in range(0, column_count):
            packet = self._socket.receive_packet()
            GBASELOGGER.debug("Receive column packet and parse packet.")            
            columns[i] = self._protocol.parse_column_res(packet)
        
        packet = self._socket.receive_packet()        
        eof_packet = self._handle_eof(packet)
        
        GBASELOGGER.debug("Set unread_result=True.")
        self.unread_result = True
        
        GBASELOGGER.debug("Exit: _handle_result.")
        return {'columns': columns, 'eof': eof_packet}
        
    def _send(self, command, argument=None):
        '''
        ************************************************************
            Function    : _handle_result
            Arguments   : 1) command (int)     : SQL command flag. ServerCmd.QUERY
                          2) argument (string) : SQL command. Select 1
            Return      : packets (string)
            Description : Send a command to the GBase server
        ************************************************************
        '''
        GBASELOGGER.debug("Enter: _send")
        GBASELOGGER.debug("Send command. (%s, '%s')" % (command, argument))
        GBASELOGGER.sql("Send command. (%2s, '%s')" % (command, argument))
        
        if self.unread_result:
            GBASELOGGER.error("Unread result found.")
            GBASELOGGER.debug("Exit: _send")
            raise GBaseError.InternalError("Unread result found.")
        
        try:            
            packet = self._protocol.make_command(command, argument)            
            self._socket.send_data(packet, 0)
        except AttributeError:
            GBASELOGGER.error("Invalid GBase connection.")
            GBASELOGGER.debug("Exit: _send")
            raise GBaseError.InternalError("Invalid GBase connection.")
                
        packet = self._socket.receive_packet()       
        
        GBASELOGGER.debug("Exit: _send")
        return packet

    def _trigger_next_result(self, flags):
        '''
        ************************************************************
            Function    : _trigger_next_result
            Arguments   : 1) flags (int) : Server Flag 
            Return      : 
            Description : Toggle whether there more results
                          This method checks the whether 
                          MORE_RESULTS_EXISTS is set in flags.
        ************************************************************
        '''
        GBASELOGGER.debug("Enter: _trigger_next_result.")
        
        GBASELOGGER.debug("Check server flag. '%s'" % flags)
        if flag_is_set(ServerFlag.MORE_RESULTS_EXISTS, flags):
            GBASELOGGER.debug("MORE_RESULTS_EXISTS flag exist and set _have_next_result=True.")
            self._have_next_result = True
        else:
            GBASELOGGER.debug("MORE_RESULTS_EXISTS flag not exist and set _have_next_result=False.")
            self._have_next_result = False
        
        GBASELOGGER.debug("Exit: _trigger_next_result.")

    def set_charset_collation(self, charset=None, collation=None):
        '''
        ************************************************************
            Function    : set_charset_collation
            Arguments   : 1) charset (string) : charset string
                          2) collation (string) : collation string
            Return      : 
            Description : Sets the character set and collation for the current connection
                          set_charset_collation('utf8','utf8_general_ci')
        ************************************************************
        '''
        GBASELOGGER.debug('Enter: set_charset_collation.')
        if charset:
            if isinstance(charset, int):
                self._charset_id = charset
                (charset_name, collation_name) = CharacterSet.get_info(self._charset_id)
                GBASELOGGER.debug("Get CharacterSet '%s' and collation '%s'." % 
                                  (charset_name, collation_name))
            elif isinstance(charset, str):
                (self._charset_id, charset_name, collation_name) = \
                    CharacterSet.get_charset_info(charset, collation)
                GBASELOGGER.debug("Get _charset_id '%s' charset_name '%s' collation_name '%s'." %
                                  (self._charset_id, charset_name, collation_name))
            else:
                GBASELOGGER.error("charset should be integer, string or None")
                GBASELOGGER.debug('Exit: set_charset_collation.')
                raise ValueError("charset should be integer, string or None")
        elif collation:
            (self._charset_id, charset_name, collation_name) = \
                    CharacterSet.get_charset_info(collation=collation)
            GBASELOGGER.debug("Get _charset_id '%s' charset_name '%s' collation_name '%s'." % 
                              (self._charset_id, charset_name, collation_name))
            
        query = "SET NAMES '%s' COLLATE '%s'" % (charset_name, collation_name)
        self._exec_query(query)
        # self.converter.set_charset(charset_name)
        
        GBASELOGGER.debug('Exit: set_charset_collation.')
        
    def _exec_query(self, statement):
        '''
        ************************************************************
            Function    : _exec_query
            Arguments   : 1) statement (string) : SQL command
            Return      : 
            Description : Execute a query
        ************************************************************
        '''
        GBASELOGGER.debug('Enter: _exec_query.')
        if self.unread_result is True:
            GBASELOGGER.error("Unread result found.")
            GBASELOGGER.debug('Exit: _exec_query.')
            raise GBaseError.OperationalError("Unread result found.")
                       
        self.query(statement)
        GBASELOGGER.debug('Exit: _exec_query.')
    
    def query(self, statement):
        '''
        ************************************************************
            Function    : query
            Arguments   : 1) statement (string) : SQL command
            Return      : dict
            Description : Execute a query and return result
        ************************************************************
        '''
        GBASELOGGER.debug("Enter: query")
                
        packet = self._send(ServerCmd.QUERY, statement)        
        result = self._handle_result(packet)
        
        if self._have_next_result:
            GBASELOGGER.error('Use query_iter for statements with multiple queries.')
            GBASELOGGER.debug("Exit: query")
            raise GBaseError.OperationalError('Use query_iter for statements with multiple queries.')
        
        GBASELOGGER.debug("Exit: query")
        return result
    
    def query_iterator(self, statements):
        '''
        ************************************************************
            Function    : query_iterator
            Arguments   : 1) statements (string) : multiple sql string
            Return      : 
            Description : Send one or more statements to the GBase server
        ************************************************************
        '''
        # Handle the first query result
        GBASELOGGER.debug("Enter: query_iterator")        
        packet = self._send(ServerCmd.QUERY, statements)
        yield self._handle_result(packet)
        
        # Handle next results
        while self._have_next_result:
            if self.unread_result:
                GBASELOGGER.error("Unread result found.")
                GBASELOGGER.debug("Exit: query_iterator")
                raise GBaseError.InternalError("Unread result found.")
            else:
                GBASELOGGER.debug("Handle receive packet.")
                packet = self._socket.receive_packet()
                result = self._handle_result(packet)
            yield result
        GBASELOGGER.debug("Exit: query_iterator")

    def quit(self):
        '''
        ************************************************************
            Function    : quit
            Arguments   : 
            Return      : string
            Description : Send quit packet to the GBase Server
        ************************************************************
        '''
        GBASELOGGER.debug("Enter: quit.")
        if self.unread_result:
            GBASELOGGER.error("Unread result found.")
            GBASELOGGER.debug("Exit: quit.")
            raise GBaseError.InternalError("Unread result found.")
                
        packet = self._protocol.make_command(ServerCmd.QUIT)        
        self._socket.send_data(packet, 0)
        
        GBASELOGGER.debug("Exit: quit.")
        return packet
    
    def is_connected(self):
        '''
        ************************************************************
            Function    : is_connected
            Arguments   : 
            Return      : bool
            Description : Judgment current connect is or not connected
        ************************************************************
        '''
        try:
            GBASELOGGER.debug("Enter: is_connected")
            self.ping()
        except GBaseError.Error:
            GBASELOGGER.error("connection status: disconnected.")
            GBASELOGGER.debug("Exit: is_connected")
            return False  # This method does not raise
        
        GBASELOGGER.debug("Exit: is_connected")
        return True
    
    def ping(self, reconnect=False, attempts=1, delay=0):
        '''
        ************************************************************
            Function    : ping
            Arguments   : 1) reconnect (bool): Is or not re-connect GBase server
                          2) attempts (int): Try count
                          3) delay (int): Delay time when try re-connect
            Return      : 
            Description : Send ping command to GBase server
        ************************************************************
        '''
        try:
            GBASELOGGER.debug("Enter: ping")
            
            packet = self._send(ServerCmd.PING)            
            self._handle_ok(packet)
            
            GBASELOGGER.debug("Exit: ping")
        except:
            if reconnect:                
                self.reconnect(attempts=attempts, delay=delay)
                GBASELOGGER.debug("Exit: ping")
            else:
                GBASELOGGER.error("Connection to GBase is not available.")
                GBASELOGGER.debug("Exit: ping")
                raise GBaseError.InterfaceError("Connection to GBase is not available.")
    
    def reconnect(self, attempts=1, delay=0):
        '''
        ************************************************************
            Function    : ping
            Arguments   : 1) attempts (int): Try count
                          2) delay (int): Delay time when try re-connect
            Return      : 
            Description : Attempt to reconnect to the GBase server. 
                          Default only try once. 
        ************************************************************
        '''
        GBASELOGGER.debug("Enter: reconnect.")
        counter = 0
        while counter != attempts:
            counter = counter + 1
            try:                
                self.disconnect()                
                self.connect()
            except Exception as err:
                if counter == attempts:
                    GBASELOGGER.error("Can not reconnect to GBase after %s "
                                      "attempt(%s): " % (attempts,err))
                    GBASELOGGER.debug("Exit: reconnect.")
                    raise GBaseError.InterfaceError("Can not reconnect to GBase after %s "
                                                     "attempt(%s): " % (attempts,err))
            if delay > 0:
                GBASELOGGER.debug("sleep " + str(delay))
                time.sleep(delay)
        GBASELOGGER.debug("Exit: reconnect.")
    
    def disconnect(self):
        '''
        ************************************************************
            Function    : disconnet
            Arguments   : 
            Return      : 
            Description : Disconnect from the GBase server. 
        ************************************************************
        '''
        GBASELOGGER.debug('Enter: disconnect')
        if not self._socket:
            GBASELOGGER.debug('Exit: disconnect')
            return

        try:            
            self.quit()            
            self._socket.close_tcp()
            self._socket = None
        except GBaseError.Error:
            pass  # Getting an exception would mean we are disconnected.
        GBASELOGGER.debug('Exit: disconnect')

    close = disconnect

    def cursor(self):
        '''
        ************************************************************
            Function    : cursor
            Arguments   : 
            Return      : instance of GBaseCursor class
            Description : Returns a cursor object
        ************************************************************
        '''
        GBASELOGGER.debug("Enter: cursor.")
        
        if not self.is_connected():
            GBASELOGGER.error("GBase Connection not available.")
            GBASELOGGER.debug("Exit: cursor.")
            raise GBaseError.OperationalError("GBase Connection not available.")
        
        GBASELOGGER.debug("Exit: cursor.")
        return GBaseCursor(self)
    
    def commit(self):
        '''
        ************************************************************
            Function    : commit
            Arguments   : 
            Return      : 
            Description : Commit current transaction
        ************************************************************
        '''
        GBASELOGGER.debug("Enter: commit.")        
        
        self._exec_query("COMMIT")
        
        GBASELOGGER.debug("Exit: commit.")

    def rollback(self):
        '''
        ************************************************************
            Function    : rollback
            Arguments   : 
            Return      : 
            Description : Rollback current transaction
        ************************************************************
        '''
        GBASELOGGER.debug("Enter: rollback.")
                
        self._exec_query("ROLLBACK")
        
        GBASELOGGER.debug("Exit: rollback.")
    
    def _query_info(self, query):
        '''
        ************************************************************
            Function    : _query_info
            Arguments   : 
            Return      : dict
            Description : Send a query which only returns 1 row
        ************************************************************
        '''
        GBASELOGGER.debug("Enter: _query_info")
        
        cursor = self.cursor()        
        cursor.execute(query)
        
        GBASELOGGER.debug("Exit: _query_info")
        return cursor.fetchone()
    
    def get_rows(self, count=None):
        '''
        ************************************************************
            Function    : get_rows
            Arguments   : 1) count (int) : Fetch how much rows
            Return      : a tuple with 2 elements: a list with all rows and
                          the EOF packet.
            Description : Get all rows returned by the GBase server
        ************************************************************
        '''
        GBASELOGGER.debug("Enter: get_rows")
        
        if not self.unread_result:
            GBASELOGGER.error("No result set available.")
            GBASELOGGER.debug("Exit: get_rows")
            raise GBaseError.InternalError("No result set available.")
                
        rows = self._protocol.read_result_set(self._socket, count)
        if rows[-1] is not None:            
            self._trigger_next_result(rows[-1]['server_flag'])
            self.unread_result = False

        GBASELOGGER.debug("Exit: get_rows")
        return rows
    
    def get_row(self):
        '''
        ************************************************************
            Function    : get_row
            Arguments   : 
            Return      : tuple
            Description : Get a rows returned by the GBase server
        ************************************************************
        '''
        GBASELOGGER.debug("Enter: get_row.")
        (rows, eof) = self.get_rows(count=1)
        if len(rows):
            return (rows[0], eof)
        
        GBASELOGGER.debug("Exit: get_row.")
        return (None, eof)

    def get_server_version(self):
        '''
        ************************************************************
            Function    : get_server_version
            Arguments   : 
            Return      : string
            Description : Get server version
        ************************************************************
        '''
        return self._server_version

    def get_server_info(self):
        '''
        ************************************************************
            Function    : get_server_info
            Arguments   : 
            Return      : string
            Description : Get server information
        ************************************************************
        '''
        try:
            return self._hello_res['server_version_original']
        except (TypeError, KeyError):
            return None

    def get_thread_id(self):
        try:
            return self._hello_res['server_threadid']
        except (TypeError, KeyError):
            return None

    DEFAULT_CONFIG = {
        'database': None,
        'db': None,
        'user': '',
        'password': '',
        'passwd': None,
        'host': '127.0.0.1',
        'port': 5258,
        'use_unicode': True,
        'charset': 'utf8',
        'collation': None,
        'autocommit': False,
        'time_zone': None,
        'sql_mode': None,
        'get_warnings': False,
        'raise_on_warnings': False,
        'connection_timeout': 30,
        'connect_timeout': 30,
        'client_flags': 0,                
        'dsn': None
    }
