#!/bin/env python
#coding=utf-8
from distutils.core import setup

VERSION = (3, 0, 1, None, 0)
version = '.'.join(map(str, VERSION[0:3]))
if VERSION[3] and VERSION[4]:
    version += VERSION[3] + str(VERSION[4])

setup(
      name='gbase-connector-python',
      version=version,
      description='GBase Python Connector',
      author='GBase',
	  platforms=['any'],
      py_modules=['GBaseConnector/GBaseConnection',
                  'GBaseConnector/GBaseConstants',
                  'GBaseConnector/GBaseCursor',
                  'GBaseConnector/GBaseError',
                  'GBaseConnector/GBaseErrorCode',
                  'GBaseConnector/GBaseLogger',
                  'GBaseConnector/GBaseProtocol',
                  'GBaseConnector/GBaseSocket',
                  'GBaseConnector/GBaseUtils',
                  'GBaseConnector/__init__',
                  'GBaseConnector/errmsg/__init__',
                  'GBaseConnector/errmsg/eng/__init__',
                  'GBaseConnector/errmsg/eng/client_errmsg',],
	  classifiers=['Operating System :: Microsoft :: Windows',
                   'Operating System :: POSIX',
                   'Operating System :: Unix',                   
                   'Programming Language :: Python :: 3.6'],
      )
