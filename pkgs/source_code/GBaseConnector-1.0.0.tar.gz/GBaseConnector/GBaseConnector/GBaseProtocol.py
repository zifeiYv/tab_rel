try:
    from hashlib import sha1
except ImportError:
    from sha import new as sha1
from .GBaseUtils import *
from .GBaseConstants import FieldFlag
from . import GBaseError

global GBASELOGGER


class GBaseProtocol(object):
    '''
        GBase communication protocol
    '''

    def make_auth(self, user, passwd, seed, dbname=None, charset=33,
                  client_flags=0, max_allowed_packet=1073741824):
        '''
           Function    : make_auth
           Arguments   : 1) user
                         2) seed
                         3) paasswd = None
                         4) dbname  = None                       
                         5) charset = 33  utf8
                         6) client_flags = 0
                         7) max_allowed_packet = 1073741824
           Return      : auth pack [string]
           Description : create an authentication pack
        '''
        GBASELOGGER.debug("Enter: make_auth.")
        if not seed:
            raise GBaseError.ProgrammingError('Seed missing')

        auth = self._make_auth(user, passwd, seed, dbname)
        GBASELOGGER.debug("Exit: make_auth.")
        ret = int4store(client_flags)
        ret += int4store(max_allowed_packet)
        ret += int1store(charset)
        ret += b'\x00' * 23
        ret += auth[0]
        ret += auth[1]
        ret += auth[2]
        return ret

    def make_command(self, command, param=None):
        '''
           Function    : make_command
           Arguments   : 1) user
                         2) seed
                         3) paasswd = None
                         4) dbname  = None                       
                         5) charset = 33  utf8
                         6) client_flags = 0
                         7) max_allowed_packet = 1073741824
           Return      : auth pack [string]
           Description : create an command pack
        '''
        GBASELOGGER.debug("Enter: make_command.")
        data = int1store(command)
        if param is not None:
            # data += str(param)
            if isinstance(param, str):
                data += param.encode()
                pass
            else:
                data += param
            pass

        GBASELOGGER.debug("command: " + data.decode())  # hack
        GBASELOGGER.debug("Exit: make_command.")
        return data

    def parse_hello_res(self, packet):
        '''
           Function    : parse_hello_res
           Arguments   : packet   gbase server's hello packet 
           Return      : some message come from gbase server
           Description : parse gbase server's hello message
        '''
        try:
            GBASELOGGER.debug("Enter: parse_hello_res")
            res = {}
            (packet, res['protocol']) = read_int(packet[4:], 1)
            (packet, res['server_version_original']) = read_str(packet, end=b'\x00')
            (packet, res['server_threadid']) = read_int(packet, 4)
            (packet, res['scramble']) = read_bytes(packet, 8)
            packet = packet[1:]  # Filler 1 * \x00
            (packet, res['capabilities']) = read_int(packet, 2)
            (packet, res['charset']) = read_int(packet, 1)
            (packet, res['server_status']) = read_int(packet, 2)
            packet = packet[13:]  # Filler 13 * \x00
            (packet, scramble_next) = read_bytes(packet, 12)
            res['scramble'] += scramble_next
            GBASELOGGER.debug("hello_packet: '%s' server_version: '%s'" % (res, res['server_version_original']))
            GBASELOGGER.debug("Exit: parse_hello_res")
            return res
        except Exception as err:
            GBASELOGGER.error('Parse hello package error.')
            raise GBaseError.InterfaceError('Parse hello package error.' + str(err))

    def parse_ok_res(self, packet):
        '''
           Function    : parse_ok_res
           Arguments   : packet   gbase server's ok packet 
           Return      : ok message [dict]
           Description : parse gbase server's hello message
        '''
        GBASELOGGER.debug("Enter: parse_ok_res")
        if not self.is_ok(packet):
            GBASELOGGER.debug("Exit: parse_ok_res")
            raise GBaseError.InterfaceError(errmsg="is not ok packet.")

        GBASELOGGER.debug("is ok packet")

        res = {}
        try:
            (packet, res['field_count']) = read_int(packet[4:], 1)
            (packet, res['affected_rows']) = read_lc_int(packet)
            (packet, res['insert_id']) = read_lc_int(packet)
            (packet, res['server_status']) = read_int(packet, 2)
            (packet, res['warning_count']) = read_int(packet, 2)
            if packet:
                (packet, res['info_msg']) = read_lc_str(packet)
        except ValueError:
            GBASELOGGER.debug("Exit: parse_ok_res")
            raise GBaseError.InterfaceError("Failed parsing OK packet.")
        GBASELOGGER.debug("Exit: parse_ok_res")
        return res

    def parse_error_res(self, packet):
        '''
           Function    : parse_error_res
           Arguments   : packet   gbase server's error packet 
           Return      : error infomation [dict]
           Description : parse gbase server's error message
        '''
        GBASELOGGER.debug('Enter: parse_error_res.')
        res = {}

        if not self.is_error(packet):
            GBASELOGGER.debug('Exit: parse_error_res.')
            raise ValueError("Packet is not an error packet")
        try:
            packet = packet[5:]
            (packet, res['errno']) = read_int(packet, 2)
            if packet[0] != '#':  # NO SQLState
                res['errmsg'] = packet
                res['sqlstate'] = None
            else:
                (packet, res['sqlstate']) = read_bytes(packet[1:], 5)
                res['errmsg'] = packet
        except Exception as err:
            GBASELOGGER.debug('Exit: parse_error_res.')
            raise GBaseError.InterfaceError("Failed getting Error information (%r)" % err)

        GBASELOGGER.debug('Exit: parse_error_res.')
        return res

    def parse_column_res(self, packet):
        '''
           Function    : parse_column_res
           Arguments   : packet   gbase server's column packet 
           Return      : column message [list]
           Description : parse gbase server's column message
        '''
        GBASELOGGER.debug('Enter: parse_column_res.')
        res = {}
        (packet, res['catalog']) = read_lc_str(packet[4:])
        (packet, res['db']) = read_lc_str(packet)
        (packet, res['table']) = read_lc_str(packet)
        (packet, res['org_table']) = read_lc_str(packet)
        (packet, res['name']) = read_lc_str(packet)
        (packet, res['org_name']) = read_lc_str(packet)
        packet = packet[1:]  # filler 1 * \x00
        (packet, res['charset']) = read_int(packet, 2)
        (packet, res['length']) = read_int(packet, 4)
        (packet, res['type']) = read_int(packet, 1)
        (packet, res['flags']) = read_int(packet, 2)
        (packet, res['decimal']) = read_int(packet, 1)
        packet = packet[2:]  # filler 2 * \x00

        GBASELOGGER.debug('Exit: parse_column_res.')
        return (
            res['name'],
            res['type'],
            None,  # display_size
            None,  # internal_size
            None,  # precision
            None,  # scale
            ~res['flags'] & FieldFlag.NOT_NULL,  # null_ok
            res['flags'],
        )

    def parse_column_count(self, packet):
        '''
           Function    : parse_column_count
           Arguments   : packet   gbase server's column count packet 
           Return      : column count [number]
           Description : parse gbase server's column message
        '''
        return read_lc_int(packet[4:])[1]

    def parse_eof(self, packet):
        '''
           Function    : parse_eof
           Arguments   : packet   gbase server's eof packet 
           Return      : eof message [list]
           Description : parse gbase server's eof message
        '''
        GBASELOGGER.debug('Enter: parse_eof.')

        res = {}
        if not self.is_eof(packet):
            raise ValueError("Packet is not an eof packet")
        try:
            packet = packet[5:]
            (packet, res['warning_count']) = read_int(packet, 2)
            (packet, res['server_flag']) = read_int(packet, 2)
        except ValueError:
            raise GBaseError.InterfaceError("Failed parsing eof packet.")

        GBASELOGGER.debug('Exit: parse_eof.')
        return res

    def read_result_set(self, socket, count=1):
        '''
           Function    : read_result_set
           Arguments   : socket   gbase socket 
           Return      : a tuple with 2 elements: a list with all rows and
                         the EOF packet.
           Description : parse gbase server's result set
        '''
        GBASELOGGER.debug("Enter: read_result_set.")
        rows = []
        eof = None
        rowdata = None
        i = 0
        while True:
            if eof is not None:
                break
            if i == count:
                break
            packet = socket.receive_packet()
            # if packet[0:3] == b'\xff\xff\xff':
            if packet[0] == 0 and packet[1] == 255 and packet[2] == 255 and packet[3] == 255:
                data = packet[4:]
                packet = socket.receive_packet()
                # while packet[0:3] == b'\xff\xff\xff':
                while packet[0] == 0 and packet[1] == 255 and packet[2] == 255 and packet[3] == 255:
                    data += packet[4:]
                    packet = socket.receive_packet()
                if self.is_eof(packet):
                    eof = self.parse_eof(packet)
                else:
                    data += packet[4:]
                rowdata = read_lc_str_list(data)
            elif self.is_eof(packet):
                eof = self.parse_eof(packet)
                rowdata = None
            elif self.is_error(packet):
                res = self.parse_error_res(packet)
                GBASELOGGER.error("Packet is error. Errno=%s ErrMsg=%s SqlState=%s" %
                                  (res['errno'], res['errmsg'], res['sqlstate']))
                raise GBaseError.get_gbase_exception(res)
            else:
                eof = None
                rowdata = read_lc_str_list(packet[4:])
            if eof is None and rowdata is not None:
                rows.append(rowdata)
            i += 1

        GBASELOGGER.debug("Exit: read_result_set.")
        return (rows, eof)

    def is_error(self, packet):
        '''
           Function    : is_error
           Arguments   : packet   gbase server's packet 
           Return      : true or false
           Description : return true if packet is error packet
        '''
        GBASELOGGER.debug("Enter: is_error.")
        # if packet[4] == b'\xff':
        if packet[4] == 255:  # bytes not string
            GBASELOGGER.debug("is error packet.")
            GBASELOGGER.debug("Exit: is_error.")
            return True
        GBASELOGGER.debug("is not error packet.")
        GBASELOGGER.debug("Exit: is_error.")
        return False

    def is_ok(self, packet):
        '''
           Function    : is_ok
           Arguments   : packet   gbase server's packet 
           Return      : true or false
           Description : return true if packet is ok packet
        '''
        GBASELOGGER.debug("Enter: is_ok.")
        # if packet[4] == b'\x00':
        if packet[4] == 0:  # bytes not string
            GBASELOGGER.debug("is ok packet.")
            GBASELOGGER.debug("Exit: is_ok.")
            return True
        GBASELOGGER.debug("is not ok packet.")
        GBASELOGGER.debug("Exit: is_ok.")
        return False

    def is_eof(self, packet):
        '''
           Function    : is_eof
           Arguments   : packet   gbase server's packet 
           Return      : true or false
           Description : return true if packet is eof packet
        '''
        GBASELOGGER.debug("Enter: is_eof.")
        # if packet[4] == b'\xfe':
        if packet[4] == 254:  # bytes not string
            GBASELOGGER.debug("is eof packet.")
            GBASELOGGER.debug("Exit: is_eof.")
            return True
        GBASELOGGER.debug("is not eof packet.")
        GBASELOGGER.debug("Exit: is_eof.")
        return False

    def _make_passwd(self, passwd, seed):
        GBASELOGGER.debug("Enter: _make_passwd.")
        hash4 = None
        try:
            hash1 = sha1(passwd.encode()).digest()
            hash2 = sha1(hash1).digest()
            hash3 = sha1(seed + hash2).digest()
            xored = [unpack_int(h1) ^ unpack_int(h3) for (h1, h3) in zip(hash1, hash3)]
            hash4 = struct.pack('20B', *xored)
        except Exception as err:
            GBASELOGGER.debug("Exit: _make_passwd.")
            raise GBaseError.InterfaceError('Failed make password; %s' % err)
        GBASELOGGER.debug("Exit: _make_passwd.")
        return hash4

    def _make_auth(self, user, passwd, seed, dbname=None):
        '''
           Function    : _make_auth
           Arguments   : user   gbase server's packet
                         passwd
                         dbname                         
                         seed
           Return      : [user, passwd, db]
           Description : return true if packet is eof packet
        '''
        GBASELOGGER.debug("Enter: _make_auth.")
        if user is not None and len(user) > 0:
            # if isinstance(user, 'utf8'):
            #    user = user.encode('utf8')
            _username = user.encode() + b'\x00'
        else:
            GBASELOGGER.debug("Exit: _make_auth.")
            raise GBaseError.OperationalError('user cannot be None or empty.')

        if passwd is not None and len(passwd) > 0:
            # if isinstance(passwd, str):
            #    passwd = passwd.encode('utf8')
            _password = int1store(20) + self._make_passwd(passwd, seed)
        else:
            _password = b''
            # GBASELOGGER.debug("Exit: _make_auth.")
            # raise GBaseError.OperationalError('passwd cannot be None.')

        if dbname is not None and len(dbname) > 0:
            # if isinstance(dbname, str):
            #    dbname = dbname.encode('utf8')
            _dbname = dbname.encode() + b'\x00'
        else:
            _dbname = b'\x00'
        GBASELOGGER.debug("Exit: _make_auth.")
        return (_username, _password, _dbname)
