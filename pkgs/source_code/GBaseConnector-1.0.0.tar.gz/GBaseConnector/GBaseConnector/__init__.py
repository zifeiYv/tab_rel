from GBaseConnector.GBaseConnection import GBaseConnection
apilevel = 2.0
threadsafety = 1
paramstyle = 'pyformat'


def connect(**kwargs):
    """Shortcut for creating a GBaseConnection object."""
    return GBaseConnection(**kwargs)


Connect = connect
